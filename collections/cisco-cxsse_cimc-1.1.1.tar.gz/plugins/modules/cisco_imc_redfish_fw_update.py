#!/usr/bin/env python
from ansible.module_utils.basic import AnsibleModule

DOCUMENTATION = '''
---
module: cisco_imc_redfish_fw_update
short_description: Updates IMC firmware via Redfish REST API  REQUIRES CIMC v4.1+ . NOTE: API only seems to support activating bios/cimc fw
version_added: "1.0.1.0"
description:
    - Updates IMC firmware via Redfish REST API
Input Params:
    timeout:
        description: Number of minutes to wait for update
        required: False
        default: 60
    component:
        description: Target component to update.. (ex: BIOS, CIMC, slot-HBA, FlexFlash-0, etc ).  Go to /redfish/v1/UpdateService/FirmwareInventory for available components.
        required: True
    remote_share:
        type: dict
        description:  Parameters related to remote file sharing containing firmware file
        suboptions:
            hostname:
                description: Hostname or IP of remote file share
                required: True

            username:
                description: username to access remote share
                required: False

            password:
                description: password to access remote share
                required: False

            type:
                description: Type of share (protocol)
                required: True
                choices: ["tftp", "scp", "sftp", "ftp", "http"]

            path:
                description: path to firmware file
                required: True

notes:
    - returns upgrade_status , fw_version, upgrade_log
requirements: ['requests']
extends_documentation_fragment: cisco.cxsse_cimc.redfish
author: "Scott Dozier (scdozier@cisco.com)"
'''

EXAMPLES = '''
  TODO
  - name:  Perform BMC firmware update
    delegate_to: localhost
    cisco_imc_redfish_fw_update:
        ip: "{{ inventory_hostname }}"
        username: "admin"
        password: "password"
        component: CIMC
        remote_share:
          hostname: 14.1.1.1
          path: 'files/ucs-c220-m4-k9-cimc.4.0.2l.bin'
          type: 'ftp'
          username: user
          password: password
        timeout: 60
    register: output

'''

def log_progress(log_string='', msg='', status=''):
    import datetime
    new_line = ("%s: %s. %s" % (datetime.datetime.now(), msg, status))
    return log_string + new_line + '\n'

def wait_for_update_completion(client, task_id, timeout=60):
    """
    Perform a DELETE at the resource with the given payload.
    Args:
        client: Redfishclient
        task_id: id to monitor
        timeout: timeout in minutes
    Returns:
        results, err
    """
    import time
    import datetime
    log_string = ''
    start = datetime.datetime.now()
    while True:
        response = client.get('TaskService/Tasks' + str(task_id))
        log_string = log_progress(log_string, str(response['Messages']),
                                  response['TaskState'])
        if 'Completed' in response['TaskState']:
            return str(response['TaskState']), log_string
        if 'Exception' in response['TaskState'] or 'Error' in response['TaskState']:
            return str(response['TaskState']), log_string
        time.sleep(15)
        if (datetime.datetime.now() - start).total_seconds() > timeout*60:
            log_string = log_progress(log_string, "Error: timeout reached!", response['TaskState'])
            return 'Error: Timeout waiting on update', log_string

def wait_for_bios_update_completion(client, timeout=60):
    """
    Performs a HTTP GET to check if firmware update is completed
    Args:
        client: Redfishclient
        timeout: timeout in minutes
    Returns:
        results, err
    """
    import time
    import datetime
    log_string = ''
    start = datetime.datetime.now()
    while True:
        response = client.get('TaskService/Tasks/BiosFwUpdate')
        log_string = log_progress(log_string, response['Oem']['Cisco']['UpdateStatus'],
                                  response['TaskState'])
        if 'Completed' in response['TaskState'] or 'Exception' in response['TaskState']:
            return response['TaskState'], log_string
        time.sleep(15)
        if (datetime.datetime.now() - start).total_seconds() > timeout*60:
            log_string = log_progress(log_string, "Error: timeout reached!", response['TaskState'])
            return 'Error: Timeout waiting on update', log_string

def wait_for_bmc_update_completion(client, timeout=60):
    """
    Performs a HTTP GET to check if firmware update is completed
    Args:
        client: Redfishclient
        timeout: timeout in minutes
    Returns:
        results, err
    """
    import time
    import datetime
    log_string = ''
    start = datetime.datetime.now()
    while True:
        response = client.get('TaskService/Tasks/BmcFwUpdate')
        log_string = log_progress(log_string, response['Oem']['Cisco']['UpdateStatus'],
                                  response['TaskState'])
        if 'Completed' in response['TaskState'] or 'Exception' in response['TaskState']:
            return response['TaskState'], log_string
        time.sleep(15)
        if (datetime.datetime.now() - start).total_seconds() > timeout*60:
            log_string = log_progress(log_string, "Error: timeout reached!", response['TaskState'])
            return 'Error: Timeout waiting on update', log_string

def wait_for_imc_connection(client, upgrade_status='', upgrade_log='', timeout=60):
    """
    Performs a HTTP GET until there is no exception (imc is resetting)
    Args:
        client: Redfishclient
        timeout: timeout in minutes
    Returns:
        upgrade_status, upgrade_log
    """
    import time
    import datetime
    log_string = upgrade_log
    start = datetime.datetime.now()
    while True:
        try:
            client.get('TaskService/Tasks')
            return upgrade_status, upgrade_log
        except:
            time.sleep(15)
            if (datetime.datetime.now() - start).total_seconds() > timeout*60:
                log_string = log_progress(log_string, "Error: timeout reached!", 'Timeout')
                return 'Error: Timeout waiting on activation', log_string,

def update_fw(client, component, remote_share, timeout):
    """
    Perform a DELETE at the resource with the given payload.
    Args:
        client: Redfishclient
        remote_share: (dict) Dict of hostname, username, password, type, path
        timeout: timeout in minutes
    Returns:
        results, err
    """
    import json
    import datetime
    import time
    start = datetime.datetime.now()
    results = {}
    err = False

    try:
        #start update
        response = client.post(path='UpdateService/Actions/UpdateService.SimpleUpdate',
                               payload={'Targets': ['/redfish/v1/UpdateService/FirmwareInventory/' +
                                                    component],
                                        'ImageURI': remote_share['hostname'] + ':/' + remote_share['path'],
                                        'TransferProtocol': remote_share['type'],
                                        'Username': remote_share.get('username', ''),
                                        'Password': remote_share.get('password', '')})
        time.sleep(20)
        #wait for task completion
        if response.text:
            task_id = json.loads(response.text)['Id']
            upgrade_status, upgrade_log = wait_for_update_completion(client, task_id,
                                                                     timeout=timeout)
        elif 'bios' in component.lower():
            upgrade_status, upgrade_log = wait_for_bios_update_completion(client,
                                                                          timeout=timeout)
        elif 'cimc' in component.lower():
            upgrade_status, upgrade_log = wait_for_bmc_update_completion(client,
                                                                         timeout=timeout)
        #activate firmware
        if 'completed' in upgrade_status.lower() or 'success' in upgrade_status.lower():
            if 'bios' in component.lower() or 'cimc' in component.lower():
                if 'bios' in component.lower():
                    fwactivate_path = 'Managers/CIMC/Actions/Oem/CiscoUCSExtensions.BiosFwActivate'
                if 'cimc' in component.lower():
                    fwactivate_path = 'Managers/CIMC/Actions/Oem/CiscoUCSExtensions.BmcFwActivate'
                timeout = (timeout*60 - (datetime.datetime.now() - start).total_seconds())/60
                upgrade_log = log_progress(upgrade_log, "Activating firmware", 'Activating')
                client.post(path=fwactivate_path, payload={})
                time.sleep(60)
                upgrade_status, upgrade_log = wait_for_imc_connection(client, upgrade_status,
                                                                      upgrade_log, timeout=timeout)
                upgrade_log = log_progress(upgrade_log, "Firmware activated", 'Completed')

        results["changed"] = True
        if 'error' in upgrade_status.lower() or 'exception' in upgrade_status.lower():
            err = True
            results["msg"] = "fw upgrade error: %s " % str(upgrade_status)
            results["changed"] = False
        results['upgrade_status'] = upgrade_status
        results['upgrade_log'] = upgrade_log

    except Exception as ex:
        err = True
        results["msg"] = "fw upgrade exception: %s " % str(ex)
        results["changed"] = False

    return results, err


def main():
    from ansible_collections.cisco.cxsse_cimc.plugins.module_utils.redfish_client \
         import RedfishClient, redfish_argument_spec
    spec = redfish_argument_spec()
    spec.update(dict(
        timeout=dict(type='int', default=60),
        remote_share=dict(type='dict', required=True),
        component=dict(type='str', required=True),
        ))
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    remote_share = module.params['remote_share']
    component = module.params['component']
    timeout = module.params['timeout']
    client = RedfishClient(module)
    results, err = update_fw(client, component, remote_share, timeout)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == '__main__':
    main()
