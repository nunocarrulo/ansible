import json
import requests
from requests.auth import HTTPBasicAuth
def redfish_argument_spec():
    return dict(
        ip=dict(type='str',
                      aliases=['hostname'],
                      fallback=(env_fallback, ['CISCO_IMC_IP'])
                ),
        username=dict(type='str',
                      aliases=['user', 'admin'],
                      fallback=(env_fallback, ['CISCO_IMC_USERNAME'])
                      ),
        password=dict(type='str',
                      aliases=['pass', 'pwd'],
                      no_log=True,
                      fallback=(env_fallback, ['CISCO_IMC_PASSWORD'])
                      ),
        port=dict(type='int',
                  default=443,
                  fallback=(env_fallback, ['CISCO_IMC_PORT'])
                  ),
        verify=dict(required=False, default=False),
        timeout=dict(required=False, default=30),
    )

class RedfishClient(object):
    def __init__(self):
        self.verify = False
        self.timeout = 30
        self.uri = 'https://10.225.228.231' + ':' + str(443)
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth('admin', 'Cisco.123')

    def post(self, payload, path):
        """
        Perform a POST at the resource with the given payload.
        Args:
          path: Path on API after /redfish/v1/
          payload: dict of payload to be sent
        Returns:
            True
        """
        response = self.session.post('%s/redfish/v1/%s' % (self.uri, path),
                                    verify=self.verify, timeout=self.timeout,
                                    json=payload)
        if response.status_code == 401:
            self.module.fail_json(msg="Redfish API returned 401: Ununauthorized,"
                                      " check username and password.")
        if not path:
            self.module.fail_json('path is required.')
        return response.text

    def patch(self, payload, path):
        """
        Perform a PATCH at the resource with the given payload.
        Args:
          path: Path on API after /redfish/v1/
          payload: dict of payload to be sent
        Returns:
            True
        """
        response = self.session.patch('%s/redfish/v1/%s' % (self.uri, path),
                                    verify=self.verify, timeout=self.timeout,
                                    json=payload)
        if response.status_code == 401:
            self.module.fail_json(msg="Redfish API returned 401: Ununauthorized,"
                                      " check username and password.")
        if not path:
            self.module.fail_json('path is required.')
        return True

    def delete(self, path):
        """
        Perform a DELETE at the resource with the given payload.
        Args:
          path: Path on API after /redfish/v1/
        Returns:
            True
        """
        response = self.session.delete('%s/redfish/v1/%s' % (self.uri, path),
                                    verify=self.verify, timeout=self.timeout)
        if response.status_code == 401:
            self.module.fail_json(msg="Redfish API returned 401: Ununauthorized,"
                                      " check username and password.")
        if not path:
            self.module.fail_json('path is required.')
        return True

    def get(self, path):
        """
        Perform a GET at the resource with the given payload.
        Args:
          path: Path on API after /redfish/v1/
        Returns:
            dict
        """
        response = self.session.get('%s/redfish/v1/%s' % (self.uri, path),
                                    verify=self.verify, timeout=self.timeout)
        if response.status_code == 401:
            self.module.fail_json(msg="Redfish API returned 401: Ununauthorized,"
                                      " check username and password.")
        if not path:
            self.module.fail_json('path is required.')
        return response.text


if __name__ == '__main__':
    client = RedfishClient()
    #print(client.post(path='Managers/CIMC/Actions/Oem.BmcFwActivate',payload={}))
    #print(client.get('UpdateService/FirmwareInventory'))
    #print(client.get('Managers/CIMC/Actions/Oem/CiscoUCSExtensions'))
    #print(client.get('TaskService/Tasks/402'))
    print(client.get('TaskService/Tasks/BmcFwUpdate'))