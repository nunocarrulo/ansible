# cisco.cxsse_cimc
Anisble collection for controlling Cisco UCS-C servers via IMC.

* Collection is forked from original IMC ansible module: https://github.com/CiscoUcs/imc-ansible .
* CX SSE team has expanded capabilities of original module as well as fixed small issues.
* Apache License, Version 2.0 (the "License")

# install
- ansible must be installed
```
sudo pip install ansible
```
- you will need the latest imcsdk.
```
Via pypi:
pip install imcsdk


Via git:

git clone https://github.com/ciscoucs/imcsdk
cd imcsdk
sudo make install
```
- Clone this repository and install via ansible-galaxy which can be done in two ways:

1.  ansible-galaxy collection install git+https://username:password@<url>.git

OR

2. In your project, create a collections/requirements.yml file.  AWX/Tower will install the collection

```code-block:: yaml

    collections:
      - name: https://username:password@<url>.git
        type: git
```
OR

3.  Download one of the tgz files from the builds directory, then install it locally

ansible-galaxy collection install cisco-cxsse_cimc-1.1.1.tar.gz -p ./collections

You can change where ansible looks for collection by changing the environment variable ANSIBLE_COLLECTIONS_PATH.

```

# usage
View examples in the examples/ directory.  Modules are intended to be used against a inventory of UCS hosts.

Example:

```yaml
- name: Reset CIMC
  hosts: all
  become: no
  gather_facts: no
  collections:
    - cisco.cxsse_cimc

  tasks:

    - name: Reset the CIMC
      delegate_to: localhost
      cisco_imc_server:
        state: cimc-reset
        timeout: 300
        ip: "{{ inventory_hostname }}"
        username: "admin"
        password: "password"

- name: Upgrade HUU
  hosts: all
  become: no
  gather_facts: no
  collections:
    - cisco.cxsse_cimc
  tasks:

  - name:  Perform HUU firmware update
    delegate_to: localhost
    cisco_imc_huu_update:
        ip: "{{ inventory_hostname }}"
        username: "admin"
        password: "password"
        remote_share:
          ip: 14.2.177.81
          path: 'ucs-c220m4-huu-4.0.2h.iso'
          type: 'www'
          username: demo
          password: demo
        update_component: all
        verify_update: no
        cimc_secure_boot: no
        timeout: 240
        stop_on_error: yes
    register: output

  - name: Output Update Summary
    debug:
      msg: "{{ output.upgrade_summary }}"

  - name: Output Update Log
    debug:
      msg: "{{ output.upgrade_log.split('\n') }}"
```

# sample run

```
➔ ansible-playbook -i inventory test_upgrade.yml


PLAY [Run upgrade] ***********************************************************************************************************************************************************************************************

TASK [Perform HUU firmware update] *******************************************************************************************************************************************************************************
[WARNING]: The value "False" (type bool) was converted to "'False'" (type string). If this does not look like what you expect, quote the entire value to ensure it does not change.
[WARNING]: The value "True" (type bool) was converted to "'True'" (type string). If this does not look like what you expect, quote the entire value to ensure it does not change.
changed: [1.2.3.4]

TASK [Output Update Summary] *************************************************************************************************************************************************************************************
ok: [1.2.3.4] => {
    "msg": "Update Complete CIMC Completed, I350 Completed, 3108AB-8i Completed, UCS VIC 1227T Completed, BIOS Completed, "
}

TASK [Output Update Log] *****************************************************************************************************************************************************************************************
ok: [1.2.3.4] => {
    "msg": [
        "2021-02-05 12:07:28.632377: Firmware Upgrade is still running. Rebooting Host In Progress",
        "2021-02-05 12:10:11.223326: Firmware Upgrade is still running. HUU Boot In Progress",
        "2021-02-05 12:21:00.011596: Firmware Upgrade is still running. HUU Discovery In Progress",
        "2021-02-05 12:32:01.923372: Firmware Upgrade is still running. Update In Progress",
        "2021-02-05 12:46:10.595115: Firmware Upgrade is still running. Update In Progress  CIMC Completed, I350 Completed, 3108AB-8i InProgress, ",
        "2021-02-05 12:46:27.870221: Firmware Upgrade is still running. Update In Progress  CIMC Completed, I350 Completed, 3108AB-8i Completed, UCS VIC 1227T Completed, BIOS InProgress, ",
        "2021-02-05 12:52:06.161545: Firmware Upgrade is still running. Update In Progress  CIMC Completed, I350 Completed, 3108AB-8i Completed, UCS VIC 1227T Completed, BIOS Completed, ",
        "2021-02-05 12:57:14.625106: Firmware upgrade has finished. Update Complete CIMC Completed, I350 Completed, 3108AB-8i Completed, UCS VIC 1227T Completed, BIOS Completed, ",
        ""
    ]
}

PLAY RECAP *******************************************************************************************************************************************************************************************************
1.2.3.4             : ok=3    changed=1    unreachable=0    failed=0    skipped=0    rescued=0    ignored=0   


real	57m56.911s
user	5m49.122s
sys	0m52.244s

```

# Documentation

Use Ansible Doc!

Example:

```
$ ansible-doc cisco.cxsse_cimc.cisco_imc_server
> CISCO.CXSSE_CIMC.CISCO_IMC_SERVER    ()

        Configures the power state of Cisco IMC Server

OPTIONS (= is mandatory):

= ip
        Hostname or IP Address of the IMC. If the value is not specified in the task, the value of environment variable CISCO_IMC_IP will be used instead.

        type: str

= password
        Password to access IMC. If the value is not specified in the task, the value of environment variable CISCO_IMC_PASSWORD will be used instead.

        type: str

- port
        TCP port to access IMC
        [Default: 443]
        type: str

- proxy
        Proxy to access IMC. (Not yet implemented?)
        [Default: (null)]

- secure
        Determines where or not to use HTTPS. (may not be fully implemented in all modules, assume HTTPS)
        [Default: True]

= username
        Username to access IMC.  If the value is not specified in the task, the value of environment variable CISCO_IMC_USERNAME will be used instead.

        type: str


NOTES:
      * returns power_state


REQUIREMENTS:  imcsdk

INPUT PARAMS:
  chassis_id:
    description: chassis Id to be specified for C3260 platforms, if specified on LED
      it will light the chassis id.
    required: false
  interval:
    default: 5
    description: number of seconds to wait for between state change valudation tests
  locator_led:
    choices:
    - 'on'
    - 'off'
    description: enable or disable locator_led
    required: false
  server_id:
    description: Server Id to be specified for C3260 platforms
    required: false
  state:
    choices:
    - 'on'
    - shutdown
    - 'off'
    - reset
    - boot
    - cimc-reset
    description: desired power state
    required: false
  timeout:
    default: 300
    description: number of seconds to wait for state change
    required: false


AUTHOR: Branson Matheson (brmathes@cisco.com)

CXSSE MODIFICATIONS: Scott Dozier (scdozier@cisco.com)

VERSION_ADDED_COLLECTION: cisco.cxsse_cimc

EXAMPLES:

- name: boot server
  delegate_to: localhost
  cisco_imc_server:
    state: "on"
    ip: "192.168.1.1"
    username: "admin"
    password: "password"

- name: shutdown and enable indicator
  delegate_to: localhost
  cisco_imc_server:
    state: shutdown
    locator_led: on
    timeout: 300
    ip: "192.168.1.1"
    username: "admin"
    password: "password"

```