# This file needs to be copied to ansible module_utils
from __future__ import absolute_import, division, print_function
try:
    import imcsdk
    from imcsdk.imchandle import ImcHandle
    HAS_IMCSDK = True
except:
    HAS_IMCSDK = False
import datetime
import time
from ansible.module_utils.basic import env_fallback

def cisco_imc_argument_spec():
    return dict(
        ip=dict(type='str',
                      aliases=['hostname'],
                      fallback=(env_fallback, ['CISCO_IMC_IP'])
                ),
        username=dict(type='str',
                      aliases=['user', 'admin'],
                      fallback=(env_fallback, ['CISCO_IMC_USERNAME'])
                      ),
        password=dict(type='str',
                      aliases=['pass', 'pwd'],
                      no_log=True,
                      fallback=(env_fallback, ['CISCO_IMC_PASSWORD'])
                      ),
        port=dict(type='int',
                  default=None,
                  fallback=(env_fallback, ['CISCO_IMC_PORT'])
                  ),
        secure=dict(required=False, default=None),
        proxy=dict(required=False, default=None),
    )


class ImcConnection():

    @staticmethod
    def is_login_param(param):
        return param in ["ip", "username", "password",
                         "port", "secure", "proxy", "server"]

    def __init__(self, module):
        if HAS_IMCSDK is False:
            results = {}
            results["msg"] = "imcsdk is not installed"
            module.fail_json(**results)
        self.module = module
        self.handle = None

    def wait_for_login(self, timeout, timeout_msg="Timeout: Unable to login to IMC"):
        connected = False
        start = datetime.datetime.now()
        ansible = self.module.params
        server = ansible.get('server')
        server = ImcHandle(ip=self.module.params["ip"],
                            username=self.module.params["username"],
                            password=self.module.params["password"],
                            port=self.module.params["port"],
                            secure=self.module.params["secure"],
                            proxy=self.module.params["proxy"])
        while not connected:
            try:
                # If the session is already established,
                # this will validate the session
                connected = server.login()
            except Exception as e:
                # IMC may been in the middle of activation,
                # hence connection would fail
                print("Login to IMC failed: %s", str(e))

            if not connected:
                try:
                    print("Login to IMC, elapsed time %ds",
                            (datetime.datetime.now() - start).total_seconds())
                    server.login(force=True)
                    print("Login successful")
                    server.logout()
                    connected = True
                except:
                    print("Login failed. Sleeping for 20 seconds")
                    time.sleep(20)
                if (datetime.datetime.now() - start).total_seconds() > timeout:
                    raise Exception(timeout_msg)
        return connected

    def login(self,force=False):
        ansible = self.module.params
        server = ansible.get('server')
        if server:
            return server

        results = {}
        try:
            server = ImcHandle(ip=self.module.params["ip"],
                               username=self.module.params["username"],
                               password=self.module.params["password"],
                               port=self.module.params["port"],
                               secure=self.module.params["secure"],
                               proxy=self.module.params["proxy"])
            server.login(force=force)
        except Exception as e:
            results["msg"] = str(e)
            self.module.fail_json(**results)
        self.handle = server
        return server

    def logout(self):
        server = self.module.params.get('server')
        if server:
            # we used a pre-existing handle from a task.
            # do not logout
            return False

        if self.handle:
            self.handle.logout()
            return True
        return False
