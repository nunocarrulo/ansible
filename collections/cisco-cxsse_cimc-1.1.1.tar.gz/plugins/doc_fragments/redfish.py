class ModuleDocFragment(object):
    DOCUMENTATION = '''
options:
  ip:
    description:
        - Hostname or IP Address of the IMC. If the value is not specified in the task, the value of environment variable CISCO_IMC_IP will be used instead.
    type: str
    required: True
  username:
    description:
    - Username to access IMC.  If the value is not specified in the task, the value of environment variable CISCO_IMC_USERNAME will be used instead.
    type: str
    required: True
  password:
    description:
    - Password to access IMC. If the value is not specified in the task, the value of environment variable CISCO_IMC_PASSWORD will be used instead.
    type: str
    required: True
  port:
    description:
    - TCP port to access IMC
    default: 443
    type: str
    required: False
  verify:
    description:
    - Determines if certificates should be verified
    default: False
    required: False
'''