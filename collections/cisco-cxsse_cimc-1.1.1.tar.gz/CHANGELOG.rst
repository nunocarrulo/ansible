==================================
CXSSE_CIMC IMC Ansible Collection
==================================

.. contents:: Topics

v1.1.1
======

Bugfixes
--------
- Changed documenation on huu_update to indicate all,hdd is used to all update hdds
- Fixed issue with password_policy that was breaking ansible-doc


v1.1.0
======

Minor Changes
-------------

- Added cisco_imc_redfish_bios_fw_update for 3.0-4.1 REST based firmware updates
- Added cisco_imc_redfish_cimc_fw_update for 3.0-4.1 REST based firmware updates
- Added cisco_imc_redfish_fw_update fo4 4.1+ REST based firmware updates

Bugfixes
--------
- Fixed cisco_imc_server which would error if already powered off or on


v1.0.0
======

First version forked from imc-ansible

Minor Changes
-------------

- Reworked imc-ansible to ansible collection
- Added cisco_imc_huu_update , module for performing huu updates
- Added 'cimc-reset' to cisco_imc_server
- Added pull request cisco_imc_snmp
- Modifications to module_utils/cisco_imc.py to support force login or waiting for login
- Documentation changes to all modules to specify localhost
- Removed cisco_imc_login and cisco_imc_logout from collection as it wasnt widely supported by other modules
- Reworked all modules so they have a consistent base config (ip,username,password) and base documentation
- Changed port to snmp_port in cisco_imc_snmp

Bugfixes
--------
- Various bug fixes to cisco_imc_server which were found during testing