from imcsdk.imchandle import ImcHandle
from imcsdk.mometa.equipment.EquipmentLocatorLed \
    import EquipmentLocatorLed, EquipmentLocatorLedConsts
from imcsdk.mometa.equipment.EquipmentChassisLocatorLed \
    import EquipmentChassisLocatorLed, EquipmentChassisLocatorLedConsts
import logging
# Create a connection handle
handle = ImcHandle("10.225.228.231", "admin", "Cisco.123")
log = logging.getLogger('imc')
# Login to the server
handle.login()
server = handle
#led_mo = EquipmentLocatorLed(parent_mo_or_dn="sys/rack-unit-1")
#server = handle.query_dn("sys/rack-unit-1")
#server.admin_power = 'bmc-reset-immediate'
#print(led_mo)
#commit it
#handle.set_mo(server)
from imcsdk.utils.imcfirmwareinstall import firmware_huu_update , firmware_huu_update_monitor


def monitor_huu_update(server,timeout=240,interval=30, server_id=1):
    from imcsdk.imccoreutils import IMC_PLATFORM, get_server_dn
    from imcsdk.mometa.huu.HuuFirmwareUpdater import HuuFirmwareUpdater, \
        HuuFirmwareUpdaterConsts
    from imcsdk.mometa.huu.HuuFirmwareUpdateStatus import HuuFirmwareUpdateStatus
    from imcsdk.mometa.top.TopSystem import TopSystem
    from imcsdk.mometa.huu.HuuController import HuuController
    from imcsdk.utils.imcfirmwareinstall import _has_upgrade_started, _has_upgrade_finished, \
                                                log_progress, _print_component_upgrade_summary, \
                                                _validate_connection
    import datetime
    import time
    current_status = []
    start = datetime.datetime.now()
    top_system = TopSystem()
    if handle.platform == IMC_PLATFORM.TYPE_CLASSIC:
        parent_dn = top_system.dn
    elif handle.platform == IMC_PLATFORM.TYPE_MODULAR:
        parent_dn = get_server_dn(handle, str(server_id))

    huu = HuuController(parent_mo_or_dn=parent_dn)
    huu_firmware_updater = HuuFirmwareUpdater(parent_mo_or_dn=huu.dn)
    update_obj = HuuFirmwareUpdateStatus(
            parent_mo_or_dn=huu_firmware_updater.dn)

    while True:
        try:
            update_obj = handle.query_dn(update_obj.dn)
            if _has_upgrade_started(update_obj):
                log_progress("Firmware upgrade is yet to start")

            if _has_upgrade_finished(update_obj):
                log_progress("Firmware upgrade has finished",
                             update_obj.overall_status)
                print(update_obj)
                _print_component_upgrade_summary(handle)
                break
            elif update_obj.overall_status not in current_status:
                log_progress("Firmware Upgrade is still running",
                             update_obj.overall_status)
                current_status.append(update_obj.overall_status)

            time.sleep(interval)
            secs = (datetime.datetime.now() - start).total_seconds()
            if int(secs / 60) > timeout:
                log_progress("Monitor API timeout",
                             "rerun firmware_huu_update_monitor")
                break
        except:
            _validate_connection(handle)

print('starting update....')

from imcsdk.imccoreutils import IMC_PLATFORM, get_server_dn
from imcsdk.mometa.huu.HuuFirmwareUpdater import HuuFirmwareUpdater, \
    HuuFirmwareUpdaterConsts
from imcsdk.mometa.huu.HuuFirmwareUpdateStatus import HuuFirmwareUpdateStatus
from imcsdk.mometa.top.TopSystem import TopSystem
from imcsdk.mometa.huu.HuuController import HuuController
from imcsdk.utils.imcfirmwareinstall import _has_upgrade_started, _has_upgrade_finished, \
                                            log_progress, _print_component_upgrade_summary, \
                                            _validate_connection
import datetime
import time
current_status = []
start = datetime.datetime.now()
top_system = TopSystem()
if handle.platform == IMC_PLATFORM.TYPE_CLASSIC:
    parent_dn = top_system.dn
elif handle.platform == IMC_PLATFORM.TYPE_MODULAR:
    parent_dn = get_server_dn(handle, str(server_id))

huu = HuuController(parent_mo_or_dn=parent_dn)
huu_firmware_updater = HuuFirmwareUpdater(parent_mo_or_dn=huu.dn)
update_obj = HuuFirmwareUpdateStatus(
        parent_mo_or_dn=huu_firmware_updater.dn)

update_obj = handle.query_dn(update_obj.dn)
print(update_obj)
component_upgrade_summary = handle.query_classid("HuuUpdateComponentStatus")
for obj in component_upgrade_summary:
    print("%20s: %s" % (obj.component, obj.update_status))
"""
huu_firmware_updater = firmware_huu_update(handle=server,
                                            remote_share="share/ucs-c220m4-huu-4.0.2h.iso",
                                            remote_ip='14.2.177.81',
                                            share_type='nfs',
                                            username='ucladmin',
                                            password='t3tNK7Bf',
                                            update_component='all',
                                            stop_on_error='no',
                                            verify_update='no',
                                            cimc_secure_boot='no',
                                            timeout=240,server_id=None)
monitor_huu_update(server, timeout=240, interval=30)"""