#!/usr/bin/env python
from __future__ import absolute_import, division, print_function
from ansible.module_utils.basic import AnsibleModule
try:
    from urllib.error import URLError
except:
    from urllib2 import URLError #python2
DOCUMENTATION = '''
---
module: cisco_imc_server
short_description: Configures the power state of Cisco IMC Server
version_added: "0.9.0.0"
description:
    - Configures the power state of Cisco IMC Server
Input Params:
    state:
        description: desired power state
        required: False
        choices: ["on", "shutdown", "off", "reset", "boot", "cimc-reset"]

    locator_led:
        description: enable or disable locator_led
        required: False
        choices: ["on", "off"]

    timeout:
        description: number of seconds to wait for state change
        required: False
        default: 300

    interval:
        description: number of seconds to wait for between state change valudation tests
        default: 5

    server_id:
        description: Server Id to be specified for C3260 platforms
        required: False

    chassis_id:
        description: chassis Id to be specified for C3260 platforms,
            if specified on LED it will light the chassis id.
        required: False
extends_documentation_fragment: cisco.cxsse_cimc.cisco_imc

notes:
    - returns power_state
requirements: ['imcsdk']
author: "Branson Matheson (brmathes@cisco.com)"

cxsse modifications: Scott Dozier (scdozier@cisco.com)
'''

EXAMPLES = '''
- name: boot server
  delegate_to: localhost
  cisco_imc_server:
    state: "on"
    ip: "192.168.1.1"
    username: "admin"
    password: "password"

- name: shutdown and enable indicator
  delegate_to: localhost
  cisco_imc_server:
    state: shutdown
    locator_led: on
    timeout: 300
    ip: "192.168.1.1"
    username: "admin"
    password: "password"

'''

def reset_cimc(server, conn, params):
    from imcsdk.apis.server.serveractions import get_server_dn
    timeout = params["timeout"]
    server_dn = get_server_dn(server, '1')
    qh = server.query_dn(server_dn)
    qh.admin_power = 'bmc-reset-immediate'
    try:
        server.set_mo(qh, timeout=120)
    except Exception as ex:
        print(str(ex)) #often error on bmc-reset
    return conn.wait_for_login(timeout)

def setup_server_power(server, params, status):
    from imcsdk.apis.server.serveractions import server_power_state_get
    from imcsdk.apis.server.serveractions import server_power_up
    from imcsdk.apis.server.serveractions import server_power_down
    from imcsdk.apis.server.serveractions import server_power_down_gracefully
    from imcsdk.apis.server.serveractions import server_power_cycle

    timeout, interval = params["timeout"], params["interval"]
    server_id = params["server_id"]
    server_mo = None

    state = server_power_state_get(server, server_id=server_id)

    if state == "off":
        if status == "on" or status == "boot":
            server_mo = server_power_up(server, timeout=timeout,
                                        interval=interval, serverid_=server_id)

    elif state == "on":
        if status == "shutdown":
            server_mo = server_power_down_gracefully(server, timeout=timeout,
                                                     interval=interval, serverid_=server_id)
        elif status == "off":
            server_mo = server_power_down(server, timeout=timeout,
                                          interval=interval, serverid_=server_id)
        elif status == "boot" or status == "reset":
            server_mo = server_power_cycle(server, timeout=timeout,
                                           interval=interval, serverid_=server_id)
    if server_mo is not None:
        return True
    else:
        return False


def setup_server_led(server, params, locator_led):
    from imcsdk.apis.server.serveractions import locator_led_off
    from imcsdk.apis.server.serveractions import locator_led_on

    server_id, chassis_id = params["server_id"], params["chassis_id"]

    # no method for determining current LED status.
    if locator_led == "on":
        locator_led_on(server,
                       server_id=server_id,
                       chassis_id=chassis_id)
    elif locator_led == "off":
        locator_led_off(server,
                        server_id=server_id,
                        chassis_id=chassis_id)
    return True

def setup_server(server, conn, module):
    from imcsdk.apis.server.serveractions import server_power_state_get
    ansible = module.params
    status, locator_led = ansible["state"], ansible["locator_led"]
    changed = False

    if status is not None:
        if 'bmc-reset' in status or 'cimc-reset' in status:
            reset_cimc(server, conn, module.params)
            server = conn.login(force=True)
            changed = True
        else:
            changed = setup_server_power(server, module.params, status)

    if locator_led is not None:
        setup_server_led(server, module.params, locator_led)
        changed = True

    server_id = ansible["server_id"]
    power_state = server_power_state_get(server, server_id=server_id)
    return changed, power_state


def setup(server, conn, module):
    results = {}
    err = False

    try:
        results["changed"], results['power_state'] = setup_server(
            server, conn, module)
    except Exception as e:
        err = True
        results["msg"] = "setup error: %s " % str(e)
        results["changed"] = False

    return results, err


def main():
    from ansible_collections.cisco.cxsse_cimc.plugins.module_utils.cisco_imc \
         import ImcConnection, cisco_imc_argument_spec
    spec = cisco_imc_argument_spec()
    spec.update(dict(
            server_id=dict(required=False, type='int', default=None),
            chassis_id=dict(required=False, type='int', default=None),
            state=dict(required=False, type='str',
                       choices=["on", "shutdown", "off", "reset", "boot",
                                'cimc-reset', 'bmc-reset']),
            locator_led=dict(required=False, type='str',
                             choices=["on", "off"]),
            timeout=dict(type='int', default=300),
            interval=dict(type='int', default=5),

            # ImcHandle
            server=dict(required=False, type='dict'),

        )
    )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)

    conn = ImcConnection(module)
    server = conn.login()
    results, err = setup(server, conn, module)
    try:
        conn.logout()
    except URLError as ex:
        print('Unable to logout:  ' + str(ex) )
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == '__main__':
    main()
