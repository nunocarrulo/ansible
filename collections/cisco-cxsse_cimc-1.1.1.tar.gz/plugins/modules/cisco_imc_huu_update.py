#!/usr/bin/env python
from __future__ import absolute_import, division, print_function
from urllib.error import URLError
from ansible.module_utils.basic import AnsibleModule

DOCUMENTATION = '''
---
module: cisco_imc_server
short_description: Performs a HUU update on UCS-C server
version_added: "1.0.0.0"
description:
    - Handles a HUU update on a Cisco IMC Server
Input Params:
    update_component:
        description: The component to be updated.  Use "all,hdd" to update all components and hdd.  Other options depend on host but atleast include cimc or bios.
        required: False
        default: "all"

    verify_update:
        description: Enable or disable verifying of the update
        required: False
        default: no
        choices: ["yes", "no"]

    timeout:
        description: Number of minutes to wait for upgrade
        required: False
        default: 240

    cimc_secure_boot:
        description: Controls cimc secure boot
        required: False
        default: no
        choices: ["yes", "no"]

    server_id:
        description: Server Id to be specified for C3260 platforms
        required: False

    stop_on_error:
        description: Stops upgrade on error
        required: False
        default: no
        choices: ["yes", "no"]

    remote_share:
        type: dict
        description:  Parameters related to remote file sharing containing firmware file
        suboptions:
            ip:
                description: IP address of remote file share
                required: True

            username:
                description: username to access remote share
                required: False

            password:
                description: password to access remote share
                required: False
                default: 240

            type:
                description: type of share
                required: False
                choices: ["nfs", "www", "cifs"]

            path:
                description: path to firmware file
                required: True

notes:
    - returns upgrade_summary , upgrade_log
requirements: ['imcsdk']
extends_documentation_fragment: cisco.cxsse_cimc.cisco_imc
author: "Scott Dozier (scdozier@cisco.com)"
'''

EXAMPLES = '''
  - name: shutdown and enable indicator
    delegate_to: localhost
    cisco_imc_huu_update:
        ip: 1.1.1.1
        username: user
        password: password
        remote_share:
          ip: 2.2.2.2
          path: 'nfsshare2/ucs-c460m4-huu-2.0.9l.iso'
          type: 'nfs'
          username: user
          password: password
        update_component: all
        verify_update: no
        cimc_secure_boot: no
        timeout: 240
        stop_on_error: yes

'''



def log_progress(log_string='', msg='', status=''):
    import datetime
    new_line = ("%s: %s. %s" % (datetime.datetime.now(), msg, status))
    return log_string + new_line + '\n'

# Tracks if upgrade is over, not necessarily successful
def _has_upgrade_finished(update):
    return update.update_end_time != "NA" and len(update.overall_status)

def monitor_huu_update(server, conn, module, timeout=240, interval=10, server_id=1):
    from imcsdk.imccoreutils import IMC_PLATFORM, get_server_dn
    from imcsdk.mometa.huu.HuuFirmwareUpdater import HuuFirmwareUpdater
    from imcsdk.mometa.huu.HuuFirmwareUpdateStatus import HuuFirmwareUpdateStatus
    from imcsdk.mometa.top.TopSystem import TopSystem
    from imcsdk.mometa.huu.HuuController import HuuController
    from imcsdk.utils.imcfirmwareinstall import _has_upgrade_started, \
                                                _print_component_upgrade_summary
    import datetime
    import time
    current_status = []
    start = datetime.datetime.now()
    top_system = TopSystem()
    upgrade_log = ''
    upgrade_summary = ''
    if server.platform == IMC_PLATFORM.TYPE_CLASSIC:
        parent_dn = top_system.dn
    elif server.platform == IMC_PLATFORM.TYPE_MODULAR:
        parent_dn = get_server_dn(server, str(server_id))

    huu = HuuController(parent_mo_or_dn=parent_dn)
    huu_firmware_updater = HuuFirmwareUpdater(parent_mo_or_dn=huu.dn)
    update_obj = HuuFirmwareUpdateStatus(parent_mo_or_dn=huu_firmware_updater.dn)

    while True:
        try:
            update_obj = server.query_dn(update_obj.dn)
            upgrade_summary = update_obj.overall_status
            if _has_upgrade_started(update_obj):
                upgrade_log = log_progress(upgrade_log, "Firmware upgrade is yet to start")

            if _has_upgrade_finished(update_obj):
                upgrade_log = log_progress(upgrade_log, "Firmware upgrade has finished",
                                           update_obj.overall_status)
                if 'Error' in upgrade_summary or 'bad' in upgrade_summary: #uh oh, upgrade failed
                    try:
                        conn.logout()
                    except:
                        upgrade_log = log_progress(upgrade_log, "Unable to logout from XMLAPI", '')
                    fail_msg = 'huu upgrade error: ' + \
                               update_obj.overall_status
                    results = {'changed': False, 'upgrade_log': upgrade_log,
                               'upgrade_summary': upgrade_summary}
                    module.fail_json(msg=fail_msg, **results)
                return upgrade_log, upgrade_summary
            elif update_obj.overall_status not in current_status:
                upgrade_log = log_progress(upgrade_log, "Firmware Upgrade is still running",
                                           update_obj.overall_status)
                current_status.append(update_obj.overall_status)

            time.sleep(interval)
            secs = (datetime.datetime.now() - start).total_seconds()
            if int(secs / 60) > timeout:
                upgrade_log = log_progress(upgrade_log, "Monitor API timeout",
                                           "rerun firmware_huu_update_monitor")
                fail_msg = 'huu upgrade error: Timed out waiting for update completion.'
                results = {'changed': True,
                           'upgrade_log': upgrade_log, 'upgrade_summary': upgrade_summary}
                module.fail_json(msg=fail_msg, **results)
                return upgrade_log, upgrade_summary
        except Exception as ex:
            conn.wait_for_login(timeout=900, timeout_msg='Timed out during huu upgrade')
            server = conn.login(force=True)

def huu_firmware_update(server, conn, module):
    from imcsdk.utils.imcfirmwareinstall import firmware_huu_update
    import time
    ansible = module.params
    changed = True
    remote_share, server_id = ansible['remote_share'], ansible["server_id"]
    if server_id is not None:
        server_id = int(server_id)
    verify_update, cimc_secure_boot = ansible['verify_update'], ansible["cimc_secure_boot"]
    stop_on_error, update_component = ansible['stop_on_error'], ansible["update_component"]
    timeout = ansible['timeout']

    firmware_huu_update(handle=server,
                        remote_share=remote_share['path'],
                        remote_ip=remote_share['ip'],
                        share_type=remote_share['type'],
                        username=remote_share.get('username', ''),
                        password=remote_share.get('password', ''),
                        update_component=update_component,
                        stop_on_error=stop_on_error,
                        verify_update=verify_update,
                        cimc_secure_boot=cimc_secure_boot,
                        timeout=timeout,
                        server_id=server_id)
    #firmware_huu_update_monitor will wait and return on upgrade completion
    upgrade_log, upgrade_summary = monitor_huu_update(server, conn, module, timeout=timeout,
                                                      interval=10, server_id=server_id)
    if 'Error' not in upgrade_summary:
        time.sleep(90) #wait for cimc reset
        conn.wait_for_login(timeout=900, timeout_msg='Timed out after huu update completed.')
        server = conn.login(force=True)
    return changed, upgrade_summary, upgrade_log


def setup(server, conn, module):
    results = {}
    err = False

    try:
        returned_values = huu_firmware_update(
            server, conn, module)
        results["changed"] = returned_values[0]
        results['upgrade_summary'] = returned_values[1]
        results['upgrade_log'] = returned_values[2]
    except Exception as ex:
        err = True
        results["msg"] = "huu upgrade error: %s " % str(ex)
        results["changed"] = False

    return results, err


def main():
    from ansible_collections.cisco.cxsse_cimc.plugins.module_utils.cisco_imc \
         import ImcConnection, cisco_imc_argument_spec
    spec = cisco_imc_argument_spec()
    spec.update(dict(
            server_id=dict(required=False, type='int', default=None),
            verify_update=dict(required=False, type='str',
                               choices=["yes", "no"], default="no"),
            cimc_secure_boot=dict(required=False, type='str',
                                  choices=["yes", "no"], default="no"),
            stop_on_error=dict(required=False, type='str',
                               choices=["yes", "no"], default="no"),
            update_component=dict(required=False, type='str',
                                  default="all"),
            timeout=dict(type='int', default=300),
            remote_share=dict(type='dict', required=True),

            # ImcHandle
            server=dict(required=False, type='dict'),
        )
    )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)

    conn = ImcConnection(module)
    server = conn.login()
    results, err = setup(server, conn, module)
    try:
        conn.logout()
    except URLError as ex:
        print('Unable to logout:  ' + str(ex))
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == '__main__':
    main()
