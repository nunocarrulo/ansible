from __future__ import absolute_import, division, print_function
import json
import requests
from requests.auth import HTTPBasicAuth
from ansible.module_utils.basic import env_fallback

def redfish_argument_spec():
    return dict(
        ip=dict(type='str',
                      aliases=['hostname'],
                      fallback=(env_fallback, ['CISCO_IMC_IP'])
                ),
        username=dict(type='str',
                      aliases=['user', 'admin'],
                      fallback=(env_fallback, ['CISCO_IMC_USERNAME'])
                      ),
        password=dict(type='str',
                      aliases=['pass', 'pwd'],
                      no_log=True,
                      fallback=(env_fallback, ['CISCO_IMC_PASSWORD'])
                      ),
        port=dict(type='int',
                  default=443,
                  fallback=(env_fallback, ['CISCO_IMC_PORT'])
                  ),
        verify=dict(type='bool', required=False, default=False,),
    )

class RedfishClient(object):
    def __init__(self, module):
        self.module = module
        self.verify = module.params['verify']
        self.timeout = 30
        self.uri = 'https://' + module.params['ip'] + ':' + str(module.params['port'])
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(module.params['username'], module.params['password'])

    def post(self, payload, path):
        """
        Perform a POST at the resource with the given payload.
        Args:
          path: Path on API after /redfish/v1/
          payload: dict of payload to be sent
        Returns:
            response
        """
        response = self.session.post('%s/redfish/v1/%s' % (self.uri, path),
                                    verify=self.verify, timeout=self.timeout,
                                    json=payload)
        if response.status_code == 401:
            self.module.fail_json(msg="Redfish API returned 401: Ununauthorized,"
                                      " check username and password.")
        if response.status_code != 202 and response.status_code != 200:
            self.module.fail_json(msg="Redfish API error: " + str(response.status_code) +
                                  str(response.text))
        if not path:
            self.module.fail_json('path is required.')
        return response

    def patch(self, payload, path):
        """
        Perform a PATCH at the resource with the given payload.
        Args:
          path: Path on API after /redfish/v1/
          payload: dict of payload to be sent
        Returns:
            True
        """
        response = self.session.patch('%s/redfish/v1/%s' % (self.uri, path),
                                    verify=self.verify, timeout=self.timeout,
                                    json=payload)
        if response.status_code == 401:
            self.module.fail_json(msg="Redfish API returned 401: Unauthorized,"
                                      " check username and password.")
        if not path:
            self.module.fail_json('path is required.')
        return True

    def delete(self, path):
        """
        Perform a DELETE at the resource with the given payload.
        Args:
          path: Path on API after /redfish/v1/
        Returns:
            True
        """
        response = self.session.delete('%s/redfish/v1/%s' % (self.uri, path),
                                    verify=self.verify, timeout=self.timeout)
        if response.status_code == 401:
            self.module.fail_json(msg="Redfish API returned 401: Unauthorized,"
                                      " check username and password.")
        if not path:
            self.module.fail_json('path is required.')
        return True

    def get(self, path):
        """
        Perform a GET at the resource with the given payload.
        Args:
          path: Path on API after /redfish/v1/
        Returns:
            dict
        """
        response = self.session.get('%s/redfish/v1/%s' % (self.uri, path),
                                    verify=self.verify, timeout=self.timeout)
        if response.status_code == 401:
            self.module.fail_json(msg="Redfish API returned 401: Unauthorized,"
                                      " check username and password.")
        if not path:
            self.module.fail_json('path is required.')
        return json.loads(response.text)