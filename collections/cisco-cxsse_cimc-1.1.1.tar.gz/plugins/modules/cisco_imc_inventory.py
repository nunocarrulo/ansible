#!/usr/bin/env python

from ansible.module_utils.basic import AnsibleModule
DOCUMENTATION = '''
---
module: cisco_imc_inventory
short_description: Collect CIMC inventory
version_added: ""
description:
    - Puts CIMC inventory information into cimc_inventory host's variable.
extends_documentation_fragment: cisco.cxsse_cimc.cisco_imc

requirements: ['imcsdk']
author: "Nikolay Fedotov (nfedotov@cisco.com)"
notes:
    - returns cimc_inventory
'''

EXAMPLES = '''
- name: Gather CIMC inventory
  delegate_to: localhost
  cisco_imc_inventory:
    ip: "192.168.1.1"
    username: "admin"
    password: "password"
'''


def main():
    from ansible_collections.cisco.cxsse_cimc.plugins.module_utils.cisco_imc \
         import ImcConnection, cisco_imc_argument_spec
    from imcsdk.apis.server.inventory import inventory_get
    spec = cisco_imc_argument_spec()
    spec.update(dict(
                # ImcHandle
                server=dict(required=False, type='dict')
                    )
                )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    conn = ImcConnection(module)
    server = conn.login()
    inventory = inventory_get(server)
    conn.logout()
    module.exit_json(ansible_facts=dict(cimc_inventory=inventory[server.ip]))


if __name__ == '__main__':
    main()
